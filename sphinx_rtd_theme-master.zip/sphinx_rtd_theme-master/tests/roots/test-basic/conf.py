# -*- coding: utf-8 -*-

master_doc = 'index'
exclude_patterns = ['_build']
